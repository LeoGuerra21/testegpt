
document.addEventListener("DOMContentLoaded", () => {
    const petName = localStorage.getItem("petName");
    const whatsapp = localStorage.getItem("whatsapp");
    const petImage = localStorage.getItem("petImage");

    if (petName && whatsapp && petImage) {
        document.getElementById("petNameDisplay").innerText = petName;
        document.getElementById("petImageDisplay").src = petImage;
        document.getElementById("whatsappLink").href = `https://wa.me/${whatsapp}`;
        document.getElementById("formContainer").style.display = "none";
    }

    const petImageDisplay = document.getElementById("petImageDisplay");
    const petImageInput = document.getElementById("petImageInput");

    petImageDisplay.addEventListener("click", () => {
        if (!petName || !whatsapp || !petImage) {
            petImageInput.click();
        }
    });

    petImageInput.addEventListener("change", (event) => {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = () => {
                petImageDisplay.src = reader.result;
                localStorage.setItem("petImage", reader.result);
            };
            reader.readAsDataURL(file);
        }
    });
});

function saveData() {
    const name = document.getElementById("petNameInput").value.trim();
    const whatsapp = document.getElementById("whatsappInput").value.trim();

    if (name && whatsapp) {
        localStorage.setItem("petName", name);
        localStorage.setItem("whatsapp", whatsapp);
        location.reload();
    } else {
        alert("Preencha todos os campos.");
    }
}
